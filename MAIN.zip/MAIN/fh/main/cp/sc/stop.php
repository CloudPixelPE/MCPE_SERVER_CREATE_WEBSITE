<?php







require_once('rcon.php');

$type = "FH0";
$host = 'vs3.dc4.us'; 
$port = 19132;                      
$password = 'cfxadmin44'; 
$timeout = 3;     




$rcon = new Rcon($host, $port, $password, $timeout);



if ($rcon->connect())
{
  $rcon->send_command('stop');
}
header("Location: http://vs3.dc4.us/" . $type . "/prts/" . $port . "/cp/index.php");
?>
