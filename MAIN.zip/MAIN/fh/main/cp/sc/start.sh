sshpass -p cfxadmin44 ssh -o StrictHostKeyChecking=no root@vs3.dc4.us 'fs'" $1"
