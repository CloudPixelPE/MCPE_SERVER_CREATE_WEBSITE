<?php
$prt = 0;
exec("./start.sh " . $prt);
header("Location: http://vs3.dc4.us/" . "FH2" . "/prts/" . $prt . "/cp/index.php");
?>
