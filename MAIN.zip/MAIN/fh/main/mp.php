<?php


require("common.php"); 
if(empty($_SESSION['user'])) 
{ 
header("Location: login.php"); 
die("Redirecting to login.php"); 
} 
     



$host = 'vs3.dc4.us';
$port = mt_rand(19132, 19999);




{
    $connection = @fsockopen($host, $port);

    if (is_resource($connection))
    {
        echo($port . ":ERR_PRT_ONLINE");
        header("location: mp.php");

        fclose($connection);
    }

    else
    {
        echo("SERVER ONLINE VS3.DC4.US:" . $port);
        exec("./ms.sh " . $port);
    }
}
?>