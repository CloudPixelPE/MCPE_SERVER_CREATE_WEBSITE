service mysqld start
service httpd start
