#!/bin/bash
service httpd start
service mysqld start

chkconfig httpd on && echo ADD_SRV_BOOT [HTTPD]
chkconfig mysqld on && echo ADD_SRV_BOOT [MYSQLD]
echo SRV [ O K ]
