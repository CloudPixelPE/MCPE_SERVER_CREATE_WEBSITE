clear
echo "DC Tech Support -> Main Controller"
echo $DISPLAY


echo "Insert Data [1]"
echo "View Data   [2]"


read op



if [ $op = "1" ]
then
clear
./id.sh
else
./vd.sh
fi
