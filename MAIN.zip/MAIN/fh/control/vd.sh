clear
echo VIEW DB:
read db

sleep 0.5
clear
echo Loading...
sleep 0.5
clear

cd db
cat $db.log
read ec
clear
echo $ec . $db . LF
