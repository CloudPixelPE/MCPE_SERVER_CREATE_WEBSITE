#!/bin/sh
wall DEL SERVERS...

sudo rm -r /var/www/html/FH/prts/*
sudo rm -r /home/fh/servers/*
wall BOOT_SRV_CHCK
service mysqld start
service httpd start
exit
