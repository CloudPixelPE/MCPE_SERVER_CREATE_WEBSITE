sudo rm -r /var/www/html/FH/prts/* && echo PRTS [ OK ]
sudo rm -r /home/fh/servers/* && echo SERVER_F  [ OK ]
