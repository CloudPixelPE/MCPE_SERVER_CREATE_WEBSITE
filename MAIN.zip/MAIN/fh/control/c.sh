#!/bin/bash
clear
echo MAIN FrostHost Controller

echo $DISPLAY
echo $DISPLAY



echo UPDATE ALL SERVERS :1
echo DELETE ALL SERVERS :2
echo FH/MAIN UPDATER    :3

read op


if [ $op = "1" ]
then
clear
echo PHAR LINK [SRC.ZIP DIRECT]:
read pl
echo ENTER 4 DIGIT ACCESS CODE:
read code
if [ $code = "0417" ]
then
echo [ ACCESS CODE VAILD ]
rm -r /home/fh/main/src.zip
cd /home/fh/main
wget $pl

rm -r /home/fh/servers/*/src.zip
rm -r /home/fh/server2/*/src.zip

cp /home/fh/main/src.zip /home/fh/servers/*
cp /home/fh/main/src.zip /home/fh/servers2/*

echo COMP. $pl
else
echo [ ACCESS DENIED ]
exit
fi




fi

if [ $op = "2" ]
then
clear

sudo rm -r /home/fh/servers1/1*
echo 19132-191XX DEL [ O K ]
echo DEV/TST SERVERS ACTIVE
exit
fi
if [ $op = "3" ]
then
clear
echo Server Updater Wizard
echo $DISPLAY
echo 4-Digit Code:
read code
if [ $code = "0417" ]
then
clear
rm -rf /home/fh/servers2/1*/src
rm -rf /home/fh/servers/1*/src
cp /home/fh/main/src.zip /home/fh/servers2/1*
cp /home/fh/main/src.zip /home/fh/servers/1*
screen -ls
else
echo Authentication Error. 
echo This Incident Will be Reported!
echo "ACCESS LEVEL ERROR: $op $code" >> err.log
fi
fi

