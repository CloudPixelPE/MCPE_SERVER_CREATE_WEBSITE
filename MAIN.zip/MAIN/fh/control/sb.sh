clear
echo SECURITY BREACH DETECTED!
read exit
cls
echo $exit
sleep 0.5
cls
