clear
echo First Name: 
read fn
echo Last Name:
read ln
echo Issue:
read ie
echo Code: 
read code
echo Database:
read db

cd db

echo "$fn $ln . $ie . $code" >> $db.log

cat $db.log
sleep 0.5;
clear
exit
