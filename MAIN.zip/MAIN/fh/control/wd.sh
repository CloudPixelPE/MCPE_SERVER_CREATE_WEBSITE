#!/bin/sh
clear

echo FrostHostPRO - Account Wipe

echo $DISPLAY

echo Username:

read user
PRT="$(cat /var/www/html/FH2/server_reg/$user/prt.txt)"
echo "$user FOUND LINK : ${PRT}"


INF="$(cat /var/www/html/FH2/server_reg/$user/sd.txt)"
rm -rf /var/www/html/FH2/server_reg/$user
rm -rf /var/www/html/FH2/prts/${PRT}
rm -rf /home/fh/servers/${PRT}
rm -rf /home/fh/servers2/${PRT}

clear

echo ${INF} . ${PRT}
echo Data Wiped!

sleep 0.5
exit

