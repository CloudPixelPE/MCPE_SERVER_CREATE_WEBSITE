<script type="text/javascript">


<!-- saved from url=(0029)http://dc4code.pe.hu/cfx/sri/ -->


if(("standalone" in window.navigator) && window.navigator.standalone){

var noddy, remotes = false;

document.addEventListener('click', function(event) {

noddy = event.target;

while(noddy.nodeName !== "A" && noddy.nodeName !== "HTML") {
noddy = noddy.parentNode;
}

if('href' in noddy && noddy.href.indexOf('http') !== -1 && (noddy.href.indexOf(document.location.host) !== -1 || remotes))
{
event.preventDefault();
document.location.href = noddy.href;
}

},false);
}
document.addEventListener('touchmove', function(e) {
	e.preventDefault();
}, false);
</script>










<?php 

    require("common.php"); 
     
 
    if(empty($_SESSION['user'])) 
    { 
 
        header("Location: login.php"); 
         
  
        die("Redirecting to login.php"); 
    } 
     

     

?> 

<center>
Welcome: <?php 

echo htmlentities($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8'); 



?> 










<br /> 


      





    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
hr {
    display: block;
    height: 1px;
    border: 0;
    border-top: 1px solid red;
    margin: 1em 0;
    padding: 0; 
}

    </style>
<p>FrostHost - MCPE Servers</p>
    <br />
    <hr>
    <br />
    <br />
</html>
    <?php
 $uid = $_SESSION['user']['username'];



 $prt = file_get_contents('server_reg' . '/' . $uid . '/' . 'prt.txt');
 $prtf = ("server_reg/" . $uid . "/prt.txt");







$filename = "$prtf";

if (file_exists($filename)) {
    echo "Your Server:";
    print ("<br />");
    echo "IP: ISP.DC4.US";
    print ("<br />");
    echo "PORT: $prt";
    print ("<hr>");
    print ("<br />");
    print ("<a href='http://vs3.dc4.us/FH2/prts/$prt/cp/'>Control My Server</a>");
} else {
    print ("<a href='of.php'>Create a Server!</a>");
}



    ?>

   
<html>
</center>
</html>
