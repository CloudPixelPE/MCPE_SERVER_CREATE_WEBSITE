<?php


require("common.php"); 
if(empty($_SESSION['user'])) 
{ 
header("Location: login.php"); 
die("Redirecting to login.php"); 
} 
     

$uid = $_SESSION['user']['username'];
$file = 'server_reg/' . $uid;

























if (file_exists($file)) {
    $server_port = file_get_contents('server_reg' . '/' . $user . '/' . 'prt.txt');
    header("Location: http://vs3.dc4.us/FH/prts/" . $server_port . '/' . 'cp' . '/');
} else {
    header("Location: http://vs3.dc4.us/FH/ss.php");
}











?>
