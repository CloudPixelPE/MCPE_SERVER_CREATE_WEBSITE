
<!doctype html>
<html>
<?php
$port = $_GET["port"];
header("refresh:15;url=http://vs3.dc4.us/FH/prts/" . $port . "/cp");
?>
<head>
<meta charset="utf-8">

<link rel="canonical" href="/">
<title>FrostHost</title>
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1 user-scalable=no">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="pure-menu pure-menu-horizontal pure-menu-scrollable">
<ul class="pure-menu-list">
<p>Control Panel</p>



</ul>
</div><div class="content">
<div class="paper">
	<center>
<h2 class="content-subhead">Loading...</h2>
<img src="https://s17.postimg.io/8lejnoi67/loader.gif"></img>
</center>
</html>