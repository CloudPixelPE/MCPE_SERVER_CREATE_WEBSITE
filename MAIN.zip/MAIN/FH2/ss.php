<?php
$host = 'isp.dc4.us';
$port = mt_rand(19000, 19899);
$ip = $_SERVER['REMOTE_ADDR'];
$uid = $_GET["uid"];





{
    $connection = @fsockopen($host, $port);

    if (is_resource($connection))
    {
        echo($port . ":ERR_PRT_ONLINE");
        header("location: ss.php");

        fclose($connection);
    }







    else
    {
        exec("./ms.sh '$port' '$uid' '$ip' ");
        header("Location: sm.php?port=" . $port);
    }
}
?>
