<!doctype html>
<html>
<head>
<meta charset="utf-8">

<link rel="canonical" href="/">
<title>FrostHost</title>
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1 user-scalable=no">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="pure-menu pure-menu-horizontal pure-menu-scrollable">
<ul class="pure-menu-list">
<li class="pure-menu-item"><a href="banned.html" class="pure-menu-link"><b>Account Status</b></a></li>
</ul>
</div><div class="content">
<div class="paper">
<h2 class="content-subhead">Account Setup</h2>
<center>
<p>
<form action="conf.php" method="post">
Enter Your FrostHosting Username: <input type="text" name="uid" value="" />
<br />
<input type="submit" name="submit" value="Submit"/>
<br />
	</center>
	</p>

</html>
