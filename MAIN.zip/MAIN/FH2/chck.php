<?php
$ip = $_SERVER['REMOTE_ADDR'];
// _______________________
$bip1 = "";
$bip2 = "";
$bip3 = "";
$bip4 = "";
$bip5 = "";
$bip6 = "";
$bip7 = "";
$bip8 = "";
$bip9 = "";
$bip10 = "";
$bip11 = "";
$bip12 = "";
// _______________________

if ($ip = $bip1 or $bip2 or $bip3 or $bip4 or $bip5 or $bip6 or $bip7 or $bip8 or $bip9 or $bip10 or $bip11 or $bip12) {
header("Location: banned.html");
} else {
header("Location: index.html");
}



?>
