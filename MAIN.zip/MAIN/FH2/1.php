
<?php
echo 'IP: VS3.DC4.US PORT: ' . htmlspecialchars($_GET["port"]);
?>
