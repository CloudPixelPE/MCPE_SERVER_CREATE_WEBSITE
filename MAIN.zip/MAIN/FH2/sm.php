<!doctype html>
<html>
<head>
<meta charset="utf-8">

<link rel="canonical" href="/">
<title>FrostHost</title>
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1 user-scalable=no">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="pure-menu pure-menu-horizontal pure-menu-scrollable">
<ul class="pure-menu-list">
<li class="pure-menu-item"><a href="login.php" class="pure-menu-link"><b>Back</b></a></li>


</ul>
</div><div class="content">
<div class="paper">
<h2 class="content-subhead">Server Activated</h2>

<p>
</html>
<?php

echo 'IP: ISP.DC4.US | PORT: ' . htmlspecialchars($_GET["port"]);
$port = $_GET["port"];
?>
<html>
<br />
<p>Please click the 'Back' Button on the top left corner.</p>

	</html>

	<?php

//print( '<a href="http://vs3.dc4.us/FH/loading.php?port=' . $port . '">Control Panel</a>' );    
?>

<html>
	</p>

</html>
