sshpass -p cfxadmin44 ssh -o StrictHostKeyChecking=no root@vs3.dc4.us 'ms2'" $1 $2 $3"
