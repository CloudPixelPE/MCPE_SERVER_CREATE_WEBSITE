<?php
$uid = $_SESSION['user']['username'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<link rel="canonical" href="/">
<title>FrostHost</title>
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1 user-scalable=no">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="pure-menu pure-menu-horizontal pure-menu-scrollable">
<ul class="pure-menu-list">
<li class="pure-menu-item"><a href="setup.php" class="pure-menu-link"><b>Account Config</b></a></li>
</ul>
</div><div class="content">
<div class="paper">
<h2 class="content-subhead">Account Config</h2>

<p>
	We are Processing your request...
<br />
	ID: <?php
echo($uid);


if (empty($uid)) {
header("Location: setup_conf.php");
} else {
header("Location: ss.php?uid=" . $uid);
}
?>
<br />
<br />
<?php
print ("<a href='ss.php?uid=" . $uid . "'>It's All Good!</a>");
?>

<br />
<br />

<a href="setup_conf.php">I Dont see a name there.</a>
	</p>

</html>
