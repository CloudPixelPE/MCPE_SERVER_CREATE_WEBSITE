<?php 

    require("common.php"); 

    if(!empty($_POST)) 
    { 
 
        if(empty($_POST['username'])) 
        { 
            
            header("Location: username_error.html");
            die(); 
        } 
         
     
        if(empty($_POST['password'])) 
        { 
           header("Location: inv_login.html");
            die(); 
        } 
         
   
        if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
        { 
           header("Location: inv_login.html");
            die(); 
        } 
         
   
        $query = " 
            SELECT 
                1 
            FROM users 
            WHERE 
                username = :username 
        "; 
         
    
        $query_params = array( 
            ':username' => $_POST['username'] 
        ); 
         
        try 
        {  
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
           
            die("Failed to run query: " . $ex->getMessage()); 
        } 
         

        $row = $stmt->fetch(); 
 
        if($row) 
        { 
            header("Location: account_in_use.html");
            die();
        } 
         
    
        $query = " 
            SELECT 
                1 
            FROM users 
            WHERE 
                email = :email 
        "; 
         
        $query_params = array( 
            ':email' => $_POST['email'] 
        ); 
         
        try 
        { 
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 
            die("Failed to run query: " . $ex->getMessage()); 
        } 
         
        $row = $stmt->fetch(); 
         
        if($row) 
        { 
            header("Location: account_in_use.html");
            die();
        } 
         
   
        $query = " 
            INSERT INTO users ( 
                username, 
                password, 
                salt, 
                email 
            ) VALUES ( 
                :username, 
                :password, 
                :salt, 
                :email 
            ) 
        "; 
         
   
        $salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647)); 
         
        
        $password = hash('sha256', $_POST['password'] . $salt); 
         
  
        for($round = 0; $round < 65536; $round++) 
        { 
            $password = hash('sha256', $password . $salt); 
        } 
         
     
        $query_params = array( 
            ':username' => $_POST['username'], 
            ':password' => $password, 
            ':salt' => $salt, 
            ':email' => $_POST['email'] 
        ); 
         
        try 
        { 
       
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        } 
        catch(PDOException $ex) 
        { 

            die("Failed to run query: " . $ex->getMessage()); 
        } 
         

        header("Location: login.php"); 

        die("Redirecting to login.php"); 
    } 
     
?> 
<script type="text/javascript">

<!-- saved from url=(0029)http://dc4code.pe.hu/cfx/sri/ -->


if(("standalone" in window.navigator) && window.navigator.standalone){

var noddy, remotes = false;

document.addEventListener('click', function(event) {

noddy = event.target;

while(noddy.nodeName !== "A" && noddy.nodeName !== "HTML") {
noddy = noddy.parentNode;
}

if('href' in noddy && noddy.href.indexOf('http') !== -1 && (noddy.href.indexOf(document.location.host) !== -1 || remotes))
{
event.preventDefault();
document.location.href = noddy.href;
}

},false);
}
document.addEventListener('touchmove', function(e) {
	e.preventDefault();
}, false);
</script>
<center>
       <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="stylesheet" type="text/css" href="style.css">
<h1>Register</h1> 
<form action="register.php" method="post"> 
    Username:<br /> 
    <input type="text" name="username" value="" /> 
    <br /><br /> 
    E-Mail:<br /> 
    <input type="text" name="email" value="" /> 
    <br /><br /> 
    Password:<br /> 
    <input type="password" name="password" value="" /> 
    <br /><br /> 
    <input type="submit" value="Register" /> 
</form>
</center>